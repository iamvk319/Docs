package com.tutorialspoint;


public class TextEditor {
   private SpellChecker spellChecker;
private String a;
private int b;

   /*public TextEditor(SpellChecker spellChecker,int b, String a) {
      System.out.println("Inside TextEditor constructor."     +b+"     :"    +a);
      this.spellChecker = spellChecker;
   }
  */
   public SpellChecker getSpellChecker() {
	return spellChecker;
}

public void setSpellChecker(SpellChecker spellChecker) {
	this.spellChecker = spellChecker;
}

public String getA() 
{
    System.out.println("Inside A:  "+a);
	return a;
}
public void setA(String a)
{
	this.a = a;
}
public int getB() 
{
    System.out.println("Inside B:"    +b);
	return b;
}
public void setB(int b) {
	this.b = b;
}
public void spellCheck() 
{
      spellChecker.checkSpelling();
   }
}