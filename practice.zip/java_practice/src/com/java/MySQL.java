package com.java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MySQL{  
	public static void main(String args[]){  
		try{  
			Class.forName("oracle.jdbc.OracleDriver");  

			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@ZCCDV-Database2:1521:cuifsdev","OSDEVSL95","cucIFS#2018");  

			String sql ="select * from TRANSACTIONDEF where TRANCODE=?";
			PreparedStatement stmt=con.prepareStatement(sql);  
			stmt.setString(1, "Transfer");
			ResultSet rs=stmt.executeQuery();
			
			while(rs.next()) 
			{
				String tranId = rs.getString("TRANID");
				System.out.println("TRANID:    "+rs.getString("TRANID"));
				if(null != tranId && !tranId.isEmpty()) 
				{
					Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@ZCCDV-Database2:1521:cuifsdev","OSDEVSL95","cucIFS#2018");
					String query ="select TRANMODE from TRANSACTIONDEF where TRANID=?";
					PreparedStatement statement=connection.prepareStatement(query);  
					statement.setString(1, tranId);
					ResultSet result=statement.executeQuery();
					while(result.next()) 
					{
						System.out.println("TRANMODE:    "+result.getString("TRANMODE"));
					} 
					connection.close();  
				}
				
			}
			if(con!=null)
			con.close();  
		}
		catch(Exception e)
		{
			System.out.println(e);
		}  
	}  
}  