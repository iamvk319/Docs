package com.java;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class MySQL{
	
	
	public void doSomething(List<String> tranIds) 
	{
		try{
			
			Set<String> s = new HashSet<String>(tranIds);
			int i = 1;
			XSSFWorkbook workbook = new XSSFWorkbook();

			XSSFSheet spreadsheet = workbook.createSheet(" Employee Info ");

			XSSFRow row;
			
			Class.forName("oracle.jdbc.OracleDriver");  
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@ZCCDV-Database2:1521:cuifsdev","OSDEVSL95","cucIFS#2018");  
			Map < Integer, Object[] > empinfo = new TreeMap < Integer, Object[] >();
			empinfo.put( 1, new Object[] {"FININSTKEY", "TRANMODE", "TRANSUBTYPE", "TRANID" });
			StringBuilder sb = new StringBuilder();
			for (String tranId : s) {
				sb.append("'"+tranId+"'"+",");
			}
			String sql = "select * from TRANSACTIONDEF where TRANID in ("+sb.deleteCharAt(sb.length() - 1).toString()+")";
			PreparedStatement stmt = con.prepareStatement(sql);
			// stmt.setString(1, tranId);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				System.out.println("i:   " + i);
				empinfo.put(++i, new Object[] { rs.getString("FININSTKEY"), rs.getString("TRANMODE"),
						rs.getString("TRANSUBTYPE"), rs.getString("TRANID") });
			}
			System.out.println("empinfo:  " + empinfo);
			
			if(con!=null) {
				con.close();
			}
			Set<Integer> keyid = empinfo.keySet();
			int rowid = 0;
			for (Integer key : keyid) {
				row = spreadsheet.createRow(rowid++);
				Object [] objectArr = empinfo.get(key);
				int cellid = 0;

				for (Object obj : objectArr){
					Cell cell = row.createCell(cellid++);
					cell.setCellValue((String)obj);
				}
			}
			FileOutputStream out = new FileOutputStream(new File("D:/poiexcel/Writesheet.xlsx"));
			workbook.write(out);
			out.close();
			  
		}
		catch(Exception e)
		{
			System.out.println(e);
		} 
	}
	
	public static void main(String args[]){  
		try{
			
			List<String> tranIds = new ArrayList<String>();
			tranIds.add("1");
			tranIds.add("5212");
			tranIds.add("2");
			Class.forName("oracle.jdbc.OracleDriver");  

			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@ZCCDV-Database2:1521:cuifsdev","OSDEVSL95","cucIFS#2018");  

			String sql ="select * from TRANSACTIONDEF where TRANCODE=?";
			PreparedStatement stmt=con.prepareStatement(sql);  
			stmt.setString(1, "Transfer");
			ResultSet rs=stmt.executeQuery();
			
			while(rs.next()) 
			{
				String tranId = rs.getString("TRANID");
				System.out.println("TRANID:    "+rs.getString("TRANID"));
				if(null != tranId && !tranId.isEmpty()) 
				{
					tranIds.add(tranId);
				}
			}
			if(con!=null)
			con.close();  
			MySQL mySql = new MySQL();
			mySql.doSomething(tranIds);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}  
	}  
}  